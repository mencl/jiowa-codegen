package com.jiowa.codegen.example;

import com.jiowa.codegen.JiowaCodeGeneratorEngine;
import com.jiowa.codegen.config.JiowaCodeGenConfig;
import com.jiowa.codegen.example.generator.LetterGenerator;
import com.jiowa.codegen.example.generator.ClassGenerator;

  
public class ExampleCodeGenerationApplication 
{
    /*------------------------------------------------------------------------*\
     * Main program:                                                          *
    \*------------------------------------------------------------------------*/
        
    public static void main(String[] arguments)
    {
        // Config class:       
        JiowaCodeGenConfig config = new JiowaCodeGenConfig("jiowa.codegen.properties");
        JiowaCodeGenConfig letterconfig = new JiowaCodeGenConfig("letter.codegen.properties", "jiowa.codegen.properties");
        
        // The example generator:
        ClassGenerator classGenerator = new ClassGenerator(config);
        LetterGenerator letterGenerator = new LetterGenerator(letterconfig);
        
        // The engine which starts all registered generators        
        JiowaCodeGeneratorEngine engine = new JiowaCodeGeneratorEngine(classGenerator, letterGenerator);
        engine.start();
    } 
}
