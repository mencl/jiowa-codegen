package com.jiowa.codegen.example.generator;

import com.jiowa.codegen.config.JiowaCodeGenConfig;
import com.jiowa.codegen.example.template.bean.Letter_jgt;
import com.jiowa.codegen.generator.AbstractGenerator;


public class LetterGenerator extends AbstractGenerator
{
    /*------------------------------------------------------------------------*\
     * Constructor:                                                           *
    \*------------------------------------------------------------------------*/
    
    public LetterGenerator(JiowaCodeGenConfig config) 
    {
        super(config); 
    }
    
    /*------------------------------------------------------------------------*\
     * Public Methods:                                                        *
    \*------------------------------------------------------------------------*/
    
    @Override
    public void generate()
    {
        // Here, you could use an iteration in order 
        // to process all letter recipients: ... 
        
        Letter_jgt t = new Letter_jgt();
        t.Salutation.set_Mr();
        t.setName("Bean");
        t.setContactPerson("Mary Moneypenny");
                
        updateSourceFile("/Mail.txt", t.toString());        
    }
}
