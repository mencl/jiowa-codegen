#include "TestClass.h"


int TestClass::getNumber()
{
    return number;
}

int TestClass::setNumber(int value)
{
    number = value;
}

string TestClass::getText()
{
    return text;
}

string TestClass::setText(string value)
{
    text = value;
}         
                 

 