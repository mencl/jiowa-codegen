#ifndef TESTCLASS_H   
#define TESTCLASS_H

#include <string>

class TestClass 
{
  protected:
    int number;
    string text; 
    
  public:    
    TestClass(int number, string text)
    {
    }
    
    int getNumber();
    void setNumber(int value);
    string getText();
    void setText(string value);         
};
       
#endif

 