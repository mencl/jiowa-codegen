package example;    
  
public class MyClass  
{ 
    protected Long number;      
    protected String text;       
    
    /**
     * Constructor with all attributes.
     */
    public MyClass(Long number, String text)  
    {
        this.number = number;
        this.text = text;
    }
    
    /**
     * Returns the value of type Long for attribute number.
     * @return value of number
     */
    public Long getNumber()   
    {
        return this.number;
    }
    
    /**
     * Returns the value of type String for attribute text.
     * @return value of text
     */
    public String getText()   
    {
        return this.text;
    } 
    
    // {{ProtectedRegionStart::ManuallyWrittenCode}}    
        // ...
        // insert your customized code here!        
        // ... 
    // {{ProtectedRegionEnd}}
}