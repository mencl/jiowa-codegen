package example; 

public class TestClass 
{
    protected Integer number;
    protected String text;    
    
    public Integer getNumber()
    {
        return this.number;
    }
    
    public void setNumber(Integer value)
    {
        this.number = value;
    }
    
    public String getText()
    {
        return this.text;
    }
    
    public void setText(String value)
    {
        this.text = value;
    }         
}
