package com.jiowa.codegen.example;

import com.jiowa.codegen.JiowaCodeGeneratorEngine;
import com.jiowa.codegen.config.JiowaCodeGenConfig;
import com.jiowa.codegen.example.generator.ClassGenerator;
import com.jiowa.codegen.example.generator.LetterGenerator;

  
public class ExampleCodeGenerationApplication 
{
    /*------------------------------------------------------------------------*\
     * Main program:                                                          *
    \*------------------------------------------------------------------------*/
        
    public static void main(String[] arguments)
    {
        // Config class:       
        JiowaCodeGenConfig config = new JiowaCodeGenConfig("jiowa.codegen.properties");
        
        // The example generator:
        ClassGenerator      classGenerator  = new ClassGenerator(config);
        LetterGenerator     letterGenerator = new LetterGenerator(config);
        
        // The engine which starts all registered generators        
        JiowaCodeGeneratorEngine engine = new JiowaCodeGeneratorEngine(classGenerator, letterGenerator); 
        engine.start();
    } 
}
