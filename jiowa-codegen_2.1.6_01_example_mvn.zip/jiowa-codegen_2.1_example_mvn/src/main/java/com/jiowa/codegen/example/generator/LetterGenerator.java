package com.jiowa.codegen.example.generator;

import com.jiowa.codegen.config.JiowaCodeGenConfig;
import com.jiowa.codegen.example.template.bean.FrenchLetter_jgt;
import com.jiowa.codegen.example.template.bean.GermanLetter_jgt;
import com.jiowa.codegen.example.template.bean.Letter_jgt;
import com.jiowa.codegen.generator.AbstractGenerator;


public class LetterGenerator extends AbstractGenerator
{
    /*------------------------------------------------------------------------*\
     * Constructor:                                                           *
    \*------------------------------------------------------------------------*/
    
    public LetterGenerator(JiowaCodeGenConfig config) 
    {
        super(config); 
    }
    
    /*------------------------------------------------------------------------*\
     * Public Methods:                                                        *
    \*------------------------------------------------------------------------*/
    
    @Override
    public void generate()
    {
        // Here, you could use an iteration in order 
        // to process all letter recipients: ... 
        
        Letter_jgt letter = new Letter_jgt();
        letter.Salutation.set_Mr();
        letter.setName("Bean");
        letter.setContactPerson("Mary Moneypenny");
        
        // data insertion via upward and downward navigation 
        // in (inline) template hierarchy: 
        letter.Salutation.set_Mr().Letter_jgt().setName("Bean").setContactPerson("Mary Moneypenny");
        
        
        // two example for automatic value propagation via 'parent constructor' for multi-lingual templates:
        GermanLetter_jgt brief  = new GermanLetter_jgt(letter);
        FrenchLetter_jgt lettre = new FrenchLetter_jgt(letter);
                
        // Test output to console
        System.out.println("------------------------------------");
        System.out.println("English letter:\n" + letter);
        System.out.println("------------------------------------");
        System.out.println("German letter:\n" + brief);
        System.out.println("------------------------------------");
        System.out.println("French letter:\n" + lettre);
        
        // genereate source files into appropriate folders:
        updateSourceFile("text/Letter.txt", letter.toString());        
        updateSourceFile("text/Brief.txt", brief.toString());        
        updateSourceFile("text/Lettre.txt", lettre.toString());        
    }
}
