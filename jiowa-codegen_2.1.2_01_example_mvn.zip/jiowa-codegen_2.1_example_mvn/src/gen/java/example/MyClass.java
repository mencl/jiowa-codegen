package example;    
  
public class MyClass  
{ 
    protected Long number;      
    protected String text;       
    
    public Long getNumber()   
    {
        return this.number;
    }
    
    public void setNumber(Long value)
    {
        this.number = value;
    }
    
    public String getText()   
    {
        return this.text;
    }
    
    public void setText(String value)
    {
        this.text = value;
    } 
    
    // {{ProtectedRegionStart::SpecialMethods}}    
    public void someSpecialMethodAsExample()
    {
        // do something
    }    
    // {{ProtectedRegionEnd}}
}
            