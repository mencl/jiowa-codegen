package com.jiowa.codegen.example.generator;

import com.jiowa.codegen.config.JiowaCodeGenConfig;
import com.jiowa.codegen.example.template.bean.Attribute_jgt;
import com.jiowa.codegen.example.template.bean.Class_jgt;
import com.jiowa.codegen.generator.AbstractGenerator;

public class ClassGenerator extends AbstractGenerator
{
    /*------------------------------------------------------------------------*\
     * Constructor:                                                           *
    \*------------------------------------------------------------------------*/
    
    public ClassGenerator(JiowaCodeGenConfig config) 
    {
        super(config); 
    }
    
    /*------------------------------------------------------------------------*\
     * Public Methods:                                                        *
    \*------------------------------------------------------------------------*/
    
    @Override
    public void generate()
    {
        // Iterate over all classes, you want to generate
        // and use the following generator code... 
        
        // Class:
        Class_jgt t = new Class_jgt();
        t.setPackageName("example");
        t.setClassName("MyClass");
        
        // Attributes:
        Attribute_jgt attr1 = t.foreachAttribute.append_Attribute_jgt().setDataType("Long").setAttributeName("number");
        Attribute_jgt attr2 = t.foreachAttribute.append_Attribute_jgt().setDataType("String").setAttributeName("text");
        
        // Getter/Setter:
        t.foreachAttribute.append_GetterSetter_jgt(attr1); // copy constructor for variable values
        t.foreachAttribute.append_GetterSetter_jgt(attr2); // copy constructor for variable values
        
        String path = t.getPackageName().replace('.', '/');
        updateSourceFile(path +"/MyClass.java", t.toString());        
    }
}
